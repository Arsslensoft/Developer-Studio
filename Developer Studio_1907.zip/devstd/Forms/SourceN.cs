﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar.Metro;
using System.IO;
using System.Diagnostics;


namespace devstd
{
    public partial class SourceN : MetroForm
    {
        public string FileWrit = null;
        void WriteSample(string code, string filter)
        {
            try
            {

                if (!checkBoxX1.Checked)
                {
                    SaveFileDialog sfd = new SaveFileDialog();
                    sfd.Filter = filter;
                    sfd.Title = "Save Program";
                    if (sfd.ShowDialog() == DialogResult.OK)
                        File.WriteAllText(sfd.FileName, code);

                    FileWrit = sfd.FileName;
                }
                else
                {
                    if (!Directory.Exists(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\DS15"))
                        Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\DS15");

               if (!Directory.Exists(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\DS15\Sources"))
                   Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\DS15\Sources");

               if (!Directory.Exists(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\DS15\Projects"))
                   Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\DS15\Projects");

             

                    string srcdir = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\DS15\Sources\";

                    if (!Directory.Exists(srcdir + filter.Split('|')[1].Replace("*.", "").ToUpper()))
                        Directory.CreateDirectory(srcdir + filter.Split('|')[1].Replace("*.", "").ToUpper());

                    string filename = srcdir + filter.Split('|')[1].Replace("*.", "").ToUpper() + @"\TEMP_" + DateTime.Now.ToFileTime().ToString() + filter.Split('|')[1].Replace("*", "");
                       if (!string.IsNullOrEmpty(textBoxX1.Text))
                           filename = srcdir + filter.Split('|')[1].Replace("*.", "").ToUpper() + @"\" + textBoxX1.Text;

                    File.WriteAllText(filename, code);
                    FileWrit = filename;
                }
             

            }
            catch
            {

            }
            finally
            {

                this.Close();
            }
        }
    
        public SourceN()
        {
          
            InitializeComponent();
        }

        private void pascalbtn_Click(object sender, EventArgs e)
        {
            WriteSample("program programname; "+ Environment.NewLine + "uses crt;"+Environment.NewLine +Environment.NewLine+ "begin"+Environment.NewLine + Environment.NewLine + "end.", "(*.pas)|*.pas|(*.pascal)|*.pascal|(*.pp)|*.pp");

        }
        private void pascalhbtn_Click(object sender, EventArgs e)
        {
            WriteSample("program helloworld; "+ Environment.NewLine + "uses crt;"+Environment.NewLine +Environment.NewLine+ "begin"+Environment.NewLine+"Writeln('HelloWorld');"+Environment.NewLine + "readkey;"+Environment.NewLine+ "end.", "(*.pas)|*.pas|(*.pascal)|*.pascal|(*.pp)|*.pp");
        }
        private void metroTileItem3_Click(object sender, EventArgs e)
        {
            WriteSample(devstd.Properties.Resources.CScode, "(*.cs)|*.cs");
        }
        private void metroTileItem4_Click(object sender, EventArgs e)
        {
            WriteSample(devstd.Properties.Resources.VBCode, "(*.vb)|*.vb");
        }
        private void metroTileItem1_Click(object sender, EventArgs e)
        {
            WriteSample(devstd.Properties.Resources.Basicode, "(*.bas)|*.bas");
        }
        private void metroTileItem2_Click(object sender, EventArgs e)
        {
            WriteSample(devstd.Properties.Resources.Ccode, "(*.c)|*.c");
        }
        private void metroTileItem5_Click(object sender, EventArgs e)
        {
            WriteSample(devstd.Properties.Resources.Ccode, "(*.cpp)|*.cpp");
        }
        private void metroTileItem6_Click(object sender, EventArgs e)
        {
            WriteSample(devstd.Properties.Resources.ASMcode, "(*.s)|*.s");
        }
        private void metroTileItem7_Click(object sender, EventArgs e)
        {
            WriteSample(devstd.Properties.Resources.HTMLcode, "(*.html)|*.html");
        }
        private void metroTileItem8_Click(object sender, EventArgs e)
        {
            WriteSample(devstd.Properties.Resources.jscode, "(*.js)|*.js");
        }
        private void metroTileItem9_Click(object sender, EventArgs e)
        {
            WriteSample(devstd.Properties.Resources.PHPcode, "(*.php)|*.php");
        }
        private void metroTileItem10_Click(object sender, EventArgs e)
        {
            WriteSample(devstd.Properties.Resources.Xmlcode, "(*.xml)|*.xml");
        }
        private void metroTileItem11_Click(object sender, EventArgs e)
        {
            WriteSample(devstd.Properties.Resources.SQLcode, "(*.sql)|*.sql");
        }

        private void metroTileItem12_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(Application.StartupPath + @"\ASN.1\Asn1Editor.exe");
            }
            catch
            {

            }
        }

        private void SourceN_Load(object sender, EventArgs e)
        {
            int tc = 15;
            try
            {
                ////if (ILang.Count > 0)
                ////{
       
                ////    foreach (KeyValuePair<string, AvailablePlugin> pl in ILang)
                ////    {
                ////        foreach (KeyValuePair<string, string> sam in pl.Value.Instance.LanguageDefinition.Samples)
                ////        {

                ////            MetroTileItem t = new MetroTileItem();
                ////            t.Text = sam.Key;
                ////            t.TitleText = pl.Value.Instance.Developer;
                ////            t.Description = pl.Value.Instance.LanguageDefinition.Description;
                ////            t.Tag = sam.Value;
                ////            t.Name = pl.Key;
                ////            t.Click += new EventHandler(t_Click);
                          
                ////            if (tc >= 22)
                ////            {
                ////                tc = 22;
                ////                t.TileColor = (eMetroTileColor)tc;
                ////                tc = 0;
                ////            }
                ////            else
                ////                t.TileColor = (eMetroTileColor)tc;

                ////            tc++;

                ////            itemContainer1.SubItems.Add(t);
                ////        }
                      
                ////    }
                ////    itemContainer1.Refresh();
                ////    this.Focus();
                ////    itemContainer1.Focus();
                ////    this.Size = new Size(this.Width, this.Height + 1);

                ////}
            }
            catch
            {

            }
        }
        //void t_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        MetroTileItem it = (MetroTileItem)sender;
        //        WriteSample(it.Tag.ToString(), "*"+it.Name + "|*" + it.Name);

        //    }
        //    catch
        //    {

        //    }
        //}
    }
}
