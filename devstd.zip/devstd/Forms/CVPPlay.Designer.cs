using System.Windows.Forms.Integration;
namespace devstd.Forms
{
    partial class CVPPlay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.progressBarX1 = new DevComponents.DotNetBar.Controls.ProgressBarX();
            this.edithost = new System.Windows.Forms.Integration.ElementHost();
            this.Editor = new ICSharpCode.AvalonEdit.TextEditor();
            this.SuspendLayout();
            // 
            // progressBarX1
            // 
            this.progressBarX1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(242)))));
            // 
            // 
            // 
            this.progressBarX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.progressBarX1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.progressBarX1.ForeColor = System.Drawing.Color.Black;
            this.progressBarX1.Location = new System.Drawing.Point(0, 385);
            this.progressBarX1.Name = "progressBarX1";
            this.progressBarX1.ProgressType = DevComponents.DotNetBar.eProgressItemType.Marquee;
            this.progressBarX1.Size = new System.Drawing.Size(751, 11);
            this.progressBarX1.TabIndex = 0;
            this.progressBarX1.Text = "progressBarX1";
            // 
            // edithost
            // 
            this.edithost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(242)))));
            this.edithost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.edithost.ForeColor = System.Drawing.Color.Black;
            this.edithost.Location = new System.Drawing.Point(0, 0);
            this.edithost.Name = "edithost";
            this.edithost.Size = new System.Drawing.Size(751, 385);
            this.edithost.TabIndex = 0;
            this.edithost.Child = this.Editor;
            // 
            // CVPPlay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(751, 396);
            this.Controls.Add(this.edithost);
            this.Controls.Add(this.progressBarX1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "CVPPlay";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Code Visual Presentation - Player";
            this.Shown += new System.EventHandler(this.CVPPlay_Shown);
            this.ResumeLayout(false);

        }

        #endregion
        private ElementHost edithost;
        private ICSharpCode.AvalonEdit.TextEditor Editor;
        private DevComponents.DotNetBar.Controls.ProgressBarX progressBarX1;
    }
}