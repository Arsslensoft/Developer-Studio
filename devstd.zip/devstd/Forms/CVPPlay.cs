using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;
using CVP;
using devstd.utils;
using System.IO;
using ICSharpCode.AvalonEdit.Highlighting;
using ICSharpCode.AvalonEdit;
using ICSharpCode.AvalonEdit.Folding;
using System.Windows.Threading;

namespace devstd.Forms
{
    public partial class CVPPlay : DevComponents.DotNetBar.Metro.MetroForm
    {
        CVPPlayer player;
        public CVPPlay()
        {
            InitializeComponent();
        }
        public void Play(string file)
        {
            try
            {
                player = new CVPPlayer();
                player.Load(file);
                this.Text = Path.GetFileNameWithoutExtension(file)+" - Code Visual Presentation";
                player.OnCVPComplete += player_OnCVPComplete;
                player.OnCVPInstructionArrived += player_OnCVPInstructionArrived;
                Editor.IsReadOnly = true;
                Editor.TextArea.IndentationStrategy = new ICSharpCode.AvalonEdit.Indentation.CSharp.CSharpIndentationStrategy(Editor.Options);
                Editor.FontFamily = new System.Windows.Media.FontFamily("Consolas");
                if (!Speech.initialized)
                    Speech.Init();
                Editor.FontSize = 12;
                Editor.SyntaxHighlighting = HighlightingManager.Instance.GetDefinition("AL");

             
            }
            catch (Exception ex)
            {
                ELog.LogEx(ex);
            }
        }
        void player_OnCVPComplete(object sender, EventArgs e)
        {
            MessageBoxEx.Show("Presentation complete", "CVP", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
       delegate void AppendTextEDelegate(bool append,string text, int line, int colum);
       void AppendSRC(bool append, string text, int line, int colum)
        {
            try
            {
                if (this.edithost.InvokeRequired)
                {
                    AppendTextEDelegate d = new AppendTextEDelegate(AppendSRC);
                    this.edithost.BeginInvoke(d, append, text, line, colum);
                }
                else
                {
                    if (append)
                    {
                        Editor.Text += text;
                    }
                    else
                    {
                        Editor.Text =text;
                        Editor.TextArea.Caret.Line = line;
                        Editor.TextArea.Caret.Column = colum;
                    }
                }
                 


            }
            catch
            {

            }
        }
        void player_OnCVPInstructionArrived(CVPINS opcode, byte[] data, int line, int column)
        {
            try
            {
                switch (opcode)
                {
                    case CVPINS.PUSH:
                        AppendSRC(false, Encoding.UTF8.GetString(data), line, column);
                        break;
                    case CVPINS.APPEND:
                        AppendSRC(true, Encoding.UTF8.GetString(data), line, column);
                        break;
                    case CVPINS.SAYSYNC:
                        Speech.Speak(Encoding.UTF8.GetString(data));
                        break;
                    case CVPINS.SAYASYNC:
                        Speech.Speak(Encoding.UTF8.GetString(data));
                        break;

                }
            }
            catch(Exception ex)
            {
                ELog.LogEx(ex);
            }
        }

        private void CVPPlay_Shown(object sender, EventArgs e)
        {
            player.Play();
        }
    }
}