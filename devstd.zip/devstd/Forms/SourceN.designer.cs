﻿namespace devstd
{
    partial class SourceN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SourceN));
            this.pascalbtn = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.pascalhbtn = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem3 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem4 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem1 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem2 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem5 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem6 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem7 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem8 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem9 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem10 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem11 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem12 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.panelEx1 = new DevComponents.DotNetBar.PanelEx();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.textBoxX1 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.checkBoxX1 = new DevComponents.DotNetBar.Controls.CheckBoxX();
            this.metroTilePanel1 = new DevComponents.DotNetBar.Metro.MetroTilePanel();
            this.itemContainer1 = new DevComponents.DotNetBar.ItemContainer();
            this.metroTileItem16 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem13 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem14 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem15 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.panelEx1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pascalbtn
            // 
            this.pascalbtn.Name = "pascalbtn";
            this.pascalbtn.SymbolColor = System.Drawing.Color.Empty;
            this.pascalbtn.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Default;
            // 
            // 
            // 
            this.pascalbtn.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.pascalbtn.TitleText = "Pascal Hello World";
            this.pascalbtn.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.pascalbtn.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pascalbtn.Click += new System.EventHandler(this.pascalbtn_Click);
            // 
            // pascalhbtn
            // 
            this.pascalhbtn.Name = "pascalhbtn";
            this.pascalhbtn.SymbolColor = System.Drawing.Color.Empty;
            this.pascalhbtn.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Green;
            // 
            // 
            // 
            this.pascalhbtn.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.pascalhbtn.TitleText = "Pawn FilterScript";
            this.pascalhbtn.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.pascalhbtn.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F);
            this.pascalhbtn.Click += new System.EventHandler(this.pascalhbtn_Click);
            // 
            // metroTileItem3
            // 
            this.metroTileItem3.Name = "metroTileItem3";
            this.metroTileItem3.SymbolColor = System.Drawing.Color.Empty;
            this.metroTileItem3.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Orange;
            // 
            // 
            // 
            this.metroTileItem3.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem3.TitleText = "C# Program";
            this.metroTileItem3.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTileItem3.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F);
            this.metroTileItem3.Click += new System.EventHandler(this.metroTileItem3_Click);
            // 
            // metroTileItem4
            // 
            this.metroTileItem4.Name = "metroTileItem4";
            this.metroTileItem4.SymbolColor = System.Drawing.Color.Empty;
            this.metroTileItem4.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Magenta;
            // 
            // 
            // 
            this.metroTileItem4.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem4.TitleText = "VB.NET Program";
            this.metroTileItem4.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTileItem4.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F);
            this.metroTileItem4.Click += new System.EventHandler(this.metroTileItem4_Click);
            // 
            // metroTileItem1
            // 
            this.metroTileItem1.Name = "metroTileItem1";
            this.metroTileItem1.SymbolColor = System.Drawing.Color.Empty;
            this.metroTileItem1.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Blue;
            // 
            // 
            // 
            this.metroTileItem1.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem1.TitleText = "ASP Page";
            this.metroTileItem1.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTileItem1.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroTileItem1.Click += new System.EventHandler(this.metroTileItem1_Click);
            // 
            // metroTileItem2
            // 
            this.metroTileItem2.Name = "metroTileItem2";
            this.metroTileItem2.SymbolColor = System.Drawing.Color.Empty;
            this.metroTileItem2.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Teal;
            // 
            // 
            // 
            this.metroTileItem2.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem2.TitleText = "C Program";
            this.metroTileItem2.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTileItem2.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F);
            this.metroTileItem2.Click += new System.EventHandler(this.metroTileItem2_Click);
            // 
            // metroTileItem5
            // 
            this.metroTileItem5.Name = "metroTileItem5";
            this.metroTileItem5.SymbolColor = System.Drawing.Color.Empty;
            this.metroTileItem5.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Plum;
            // 
            // 
            // 
            this.metroTileItem5.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem5.TitleText = "C++ Program";
            this.metroTileItem5.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTileItem5.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F);
            this.metroTileItem5.Click += new System.EventHandler(this.metroTileItem5_Click);
            // 
            // metroTileItem6
            // 
            this.metroTileItem6.Name = "metroTileItem6";
            this.metroTileItem6.SymbolColor = System.Drawing.Color.Empty;
            this.metroTileItem6.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Coffee;
            // 
            // 
            // 
            this.metroTileItem6.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem6.TitleText = "ASM";
            this.metroTileItem6.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTileItem6.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F);
            this.metroTileItem6.Click += new System.EventHandler(this.metroTileItem6_Click);
            // 
            // metroTileItem7
            // 
            this.metroTileItem7.Name = "metroTileItem7";
            this.metroTileItem7.SymbolColor = System.Drawing.Color.Empty;
            this.metroTileItem7.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.RedOrange;
            // 
            // 
            // 
            this.metroTileItem7.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem7.TitleText = "HTML";
            this.metroTileItem7.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTileItem7.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroTileItem7.Click += new System.EventHandler(this.metroTileItem7_Click);
            // 
            // metroTileItem8
            // 
            this.metroTileItem8.Name = "metroTileItem8";
            this.metroTileItem8.SymbolColor = System.Drawing.Color.Empty;
            this.metroTileItem8.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.RedViolet;
            // 
            // 
            // 
            this.metroTileItem8.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem8.TitleText = "Javascript";
            this.metroTileItem8.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTileItem8.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F);
            this.metroTileItem8.Click += new System.EventHandler(this.metroTileItem8_Click);
            // 
            // metroTileItem9
            // 
            this.metroTileItem9.Name = "metroTileItem9";
            this.metroTileItem9.SymbolColor = System.Drawing.Color.Empty;
            this.metroTileItem9.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Olive;
            // 
            // 
            // 
            this.metroTileItem9.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem9.TitleText = "PHP";
            this.metroTileItem9.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTileItem9.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F);
            this.metroTileItem9.Click += new System.EventHandler(this.metroTileItem9_Click);
            // 
            // metroTileItem10
            // 
            this.metroTileItem10.Name = "metroTileItem10";
            this.metroTileItem10.SymbolColor = System.Drawing.Color.Empty;
            this.metroTileItem10.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.DarkOlive;
            // 
            // 
            // 
            this.metroTileItem10.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem10.TitleText = "XML";
            this.metroTileItem10.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTileItem10.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F);
            this.metroTileItem10.Click += new System.EventHandler(this.metroTileItem10_Click);
            // 
            // metroTileItem11
            // 
            this.metroTileItem11.Name = "metroTileItem11";
            this.metroTileItem11.SymbolColor = System.Drawing.Color.Empty;
            this.metroTileItem11.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Rust;
            // 
            // 
            // 
            this.metroTileItem11.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem11.TitleText = "SQL";
            this.metroTileItem11.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTileItem11.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroTileItem11.Click += new System.EventHandler(this.metroTileItem11_Click);
            // 
            // metroTileItem12
            // 
            this.metroTileItem12.Name = "metroTileItem12";
            this.metroTileItem12.SymbolColor = System.Drawing.Color.Empty;
            this.metroTileItem12.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Yellowish;
            // 
            // 
            // 
            this.metroTileItem12.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem12.TitleText = "Java";
            this.metroTileItem12.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTileItem12.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F);
            this.metroTileItem12.Click += new System.EventHandler(this.metroTileItem12_Click);
            // 
            // panelEx1
            // 
            this.panelEx1.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelEx1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.OfficeMobile2014;
            this.panelEx1.Controls.Add(this.labelX1);
            this.panelEx1.Controls.Add(this.textBoxX1);
            this.panelEx1.Controls.Add(this.checkBoxX1);
            this.panelEx1.DisabledBackColor = System.Drawing.Color.Empty;
            this.panelEx1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelEx1.Location = new System.Drawing.Point(0, 548);
            this.panelEx1.Name = "panelEx1";
            this.panelEx1.Size = new System.Drawing.Size(606, 38);
            this.panelEx1.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelEx1.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelEx1.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelEx1.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelEx1.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelEx1.Style.GradientAngle = 90;
            this.panelEx1.TabIndex = 4;
            // 
            // labelX1
            // 
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX1.Location = new System.Drawing.Point(358, 10);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(58, 23);
            this.labelX1.TabIndex = 9;
            this.labelX1.Text = "Filename : ";
            // 
            // textBoxX1
            // 
            this.textBoxX1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            // 
            // 
            // 
            this.textBoxX1.Border.Class = "TextBoxBorder";
            this.textBoxX1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX1.DisabledBackColor = System.Drawing.Color.White;
            this.textBoxX1.ForeColor = System.Drawing.Color.White;
            this.textBoxX1.Location = new System.Drawing.Point(422, 13);
            this.textBoxX1.Name = "textBoxX1";
            this.textBoxX1.Size = new System.Drawing.Size(174, 20);
            this.textBoxX1.TabIndex = 8;
            // 
            // checkBoxX1
            // 
            // 
            // 
            // 
            this.checkBoxX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.checkBoxX1.Checked = true;
            this.checkBoxX1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxX1.CheckValue = "Y";
            this.checkBoxX1.Location = new System.Drawing.Point(12, 10);
            this.checkBoxX1.Name = "checkBoxX1";
            this.checkBoxX1.Size = new System.Drawing.Size(366, 23);
            this.checkBoxX1.Style = DevComponents.DotNetBar.eDotNetBarStyle.OfficeMobile2014;
            this.checkBoxX1.TabIndex = 7;
            this.checkBoxX1.Text = "Save the file automatically";
            // 
            // metroTilePanel1
            // 
            this.metroTilePanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            // 
            // 
            // 
            this.metroTilePanel1.BackgroundStyle.Class = "MetroTilePanel";
            this.metroTilePanel1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTilePanel1.ContainerControlProcessDialogKey = true;
            this.metroTilePanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroTilePanel1.DragDropSupport = true;
            this.metroTilePanel1.ForeColor = System.Drawing.Color.White;
            this.metroTilePanel1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer1});
            this.metroTilePanel1.Location = new System.Drawing.Point(0, 0);
            this.metroTilePanel1.Name = "metroTilePanel1";
            this.metroTilePanel1.Size = new System.Drawing.Size(606, 548);
            this.metroTilePanel1.TabIndex = 5;
            this.metroTilePanel1.Text = "metroTilePanel1";
            // 
            // itemContainer1
            // 
            // 
            // 
            // 
            this.itemContainer1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer1.MultiLine = true;
            this.itemContainer1.Name = "itemContainer1";
            this.itemContainer1.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.metroTileItem16,
            this.pascalbtn,
            this.pascalhbtn,
            this.metroTileItem1,
            this.metroTileItem3,
            this.metroTileItem4,
            this.metroTileItem2,
            this.metroTileItem5,
            this.metroTileItem6,
            this.metroTileItem7,
            this.metroTileItem8,
            this.metroTileItem9,
            this.metroTileItem10,
            this.metroTileItem11,
            this.metroTileItem12,
            this.metroTileItem13,
            this.metroTileItem14,
            this.metroTileItem15});
            // 
            // 
            // 
            this.itemContainer1.TitleStyle.Class = "MetroTileGroupTitle";
            this.itemContainer1.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer1.TitleText = "Supported Languages";
            // 
            // metroTileItem16
            // 
            this.metroTileItem16.Name = "metroTileItem16";
            this.metroTileItem16.SymbolColor = System.Drawing.Color.Empty;
            this.metroTileItem16.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Azure;
            // 
            // 
            // 
            this.metroTileItem16.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem16.TitleText = "AL Hello World";
            this.metroTileItem16.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTileItem16.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F);
            this.metroTileItem16.Click += new System.EventHandler(this.metroTileItem16_Click);
            // 
            // metroTileItem13
            // 
            this.metroTileItem13.Name = "metroTileItem13";
            this.metroTileItem13.SymbolColor = System.Drawing.Color.Empty;
            this.metroTileItem13.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Blueish;
            // 
            // 
            // 
            this.metroTileItem13.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem13.TitleText = "CSS";
            this.metroTileItem13.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTileItem13.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F);
            this.metroTileItem13.Click += new System.EventHandler(this.metroTileItem13_Click);
            // 
            // metroTileItem14
            // 
            this.metroTileItem14.Name = "metroTileItem14";
            this.metroTileItem14.SymbolColor = System.Drawing.Color.Empty;
            this.metroTileItem14.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.DarkBlue;
            // 
            // 
            // 
            this.metroTileItem14.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem14.TitleText = "Powershell";
            this.metroTileItem14.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTileItem14.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F);
            this.metroTileItem14.Click += new System.EventHandler(this.metroTileItem14_Click);
            // 
            // metroTileItem15
            // 
            this.metroTileItem15.Name = "metroTileItem15";
            this.metroTileItem15.SymbolColor = System.Drawing.Color.Empty;
            this.metroTileItem15.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Yellow;
            // 
            // 
            // 
            this.metroTileItem15.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem15.TitleText = "Boo";
            this.metroTileItem15.TitleTextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTileItem15.TitleTextFont = new System.Drawing.Font("Palatino Linotype", 11.25F);
            this.metroTileItem15.Click += new System.EventHandler(this.metroTileItem15_Click);
            // 
            // SourceN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(606, 586);
            this.Controls.Add(this.metroTilePanel1);
            this.Controls.Add(this.panelEx1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SourceN";
            this.Text = "Developer Studio - New Program";
            this.Load += new System.EventHandler(this.SourceN_Load);
            this.panelEx1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.Metro.MetroTileItem pascalbtn;
        private DevComponents.DotNetBar.Metro.MetroTileItem pascalhbtn;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem3;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem4;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem1;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem2;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem5;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem6;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem7;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem8;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem9;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem10;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem11;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem12;
        private DevComponents.DotNetBar.PanelEx panelEx1;
        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX1;
        private DevComponents.DotNetBar.Controls.CheckBoxX checkBoxX1;
        private DevComponents.DotNetBar.Metro.MetroTilePanel metroTilePanel1;
        private DevComponents.DotNetBar.ItemContainer itemContainer1;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem13;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem14;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem15;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem16;
    }
}